from brain_games import main_logic
from brain_games.games import calculator


def main():
     main_logic.main_logic(calculator)

if __name__ == '__main__':
    
    main()
