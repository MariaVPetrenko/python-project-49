from brain_games import main_logic
from brain_games.games import progression


def main():
     main_logic.main_logic(progression)

if __name__ == '__main__':
    
    main()
