### Hexlet tests and linter status:
[![Actions Status](https://github.com/MariaVPetrenko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/MariaVPetrenko/python-project-49/actions)
<a href="https://codeclimate.com/github/MariaVPetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b521006fd923755e8202/maintainability" /></a>
