### Hexlet tests and linter status:
[![Actions Status](https://github.com/MariaVPetrenko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/MariaVPetrenko/python-project-49/actions)
<a href="https://codeclimate.com/github/MariaVPetrenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b521006fd923755e8202/maintainability" /></a>
<a href="https://asciinema.org/a/600423" target="_blank"><img src="https://asciinema.org/a/600423.svg" /></a>
<a href="https://asciinema.org/a/601238" target="_blank"><img src="https://asciinema.org/a/601238.svg" /></a>
