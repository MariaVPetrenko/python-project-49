from brain_games import parity_check


def main():
    parity_check.parity_check()


if __name__ == '__main__':
    main()
