from brain_games import honesty_check


def main():
    honesty_check.honesty_check()


if __name__ == '__main__':
    main()
